var senial__07__imagen_8h =
[
    [ "senial_07_en_linea", "senial__07__imagen_8h.html#a577a7eb051e1839afb5d9a63adf03c08", null ]
];