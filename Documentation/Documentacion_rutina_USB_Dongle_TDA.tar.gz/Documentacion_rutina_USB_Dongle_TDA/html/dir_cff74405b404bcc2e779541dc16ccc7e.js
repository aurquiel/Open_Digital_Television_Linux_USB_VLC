var dir_cff74405b404bcc2e779541dc16ccc7e =
[
    [ "detener_imagen.h", "detener__imagen_8h.html", "detener__imagen_8h" ],
    [ "icon_imagen.h", "icon__imagen_8h.html", "icon__imagen_8h" ],
    [ "pantalla_completa_imagen.h", "pantalla__completa__imagen_8h.html", "pantalla__completa__imagen_8h" ],
    [ "pausar_imagen.h", "pausar__imagen_8h.html", "pausar__imagen_8h" ],
    [ "reproducir_imagen.h", "reproducir__imagen_8h.html", "reproducir__imagen_8h" ],
    [ "senial_00_imagen.h", "senial__00__imagen_8h.html", "senial__00__imagen_8h" ],
    [ "senial_01_imagen.h", "senial__01__imagen_8h.html", "senial__01__imagen_8h" ],
    [ "senial_02_imagen.h", "senial__02__imagen_8h.html", "senial__02__imagen_8h" ],
    [ "senial_03_imagen.h", "senial__03__imagen_8h.html", "senial__03__imagen_8h" ],
    [ "senial_04_imagen.h", "senial__04__imagen_8h.html", "senial__04__imagen_8h" ],
    [ "senial_05_imagen.h", "senial__05__imagen_8h.html", "senial__05__imagen_8h" ],
    [ "senial_06_imagen.h", "senial__06__imagen_8h.html", "senial__06__imagen_8h" ],
    [ "senial_07_imagen.h", "senial__07__imagen_8h.html", "senial__07__imagen_8h" ],
    [ "senial_08_imagen.h", "senial__08__imagen_8h.html", "senial__08__imagen_8h" ],
    [ "senial_09_imagen.h", "senial__09__imagen_8h.html", "senial__09__imagen_8h" ],
    [ "senial_10_imagen.h", "senial__10__imagen_8h.html", "senial__10__imagen_8h" ],
    [ "usb_conectado_imagen.h", "usb__conectado__imagen_8h.html", "usb__conectado__imagen_8h" ],
    [ "usb_desconectado_imagen.h", "usb__desconectado__imagen_8h.html", "usb__desconectado__imagen_8h" ]
];