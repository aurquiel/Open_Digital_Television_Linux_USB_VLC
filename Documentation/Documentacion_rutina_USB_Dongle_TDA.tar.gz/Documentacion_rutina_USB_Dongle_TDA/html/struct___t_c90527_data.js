var struct___t_c90527_data =
[
    [ "bLock", "struct___t_c90527_data.html#a098adcd74747e8e7674dea2487098b7e", null ],
    [ "code_rate", "struct___t_c90527_data.html#af9e02b59a07b9621436a2b817f76552e", null ],
    [ "hab_error", "struct___t_c90527_data.html#a2ff0fb3f5c94be854ca420109c92c601", null ],
    [ "mode_90527", "struct___t_c90527_data.html#a34b4f6857e0089006caa15414289b985", null ],
    [ "post_BER", "struct___t_c90527_data.html#a5897d618eed6bb2ca12964c6c1b70069", null ],
    [ "pre_BER", "struct___t_c90527_data.html#a20f051aa3b1952afcc2d40d705a345e6", null ],
    [ "SNR", "struct___t_c90527_data.html#a21b6ee353feba75027a7d19d2bb38d58", null ]
];