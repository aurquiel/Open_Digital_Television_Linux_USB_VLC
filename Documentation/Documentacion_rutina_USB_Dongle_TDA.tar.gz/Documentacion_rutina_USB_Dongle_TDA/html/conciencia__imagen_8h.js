var conciencia__imagen_8h =
[
    [ "conciencia_en_linea", "conciencia__imagen_8h.html#ac14696aef3d9a339e7baf079bc49cd44", null ]
];