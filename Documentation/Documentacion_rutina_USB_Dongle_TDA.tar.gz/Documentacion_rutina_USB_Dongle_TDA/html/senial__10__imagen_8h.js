var senial__10__imagen_8h =
[
    [ "senial_10_en_linea", "senial__10__imagen_8h.html#a2519d113feff5fc2c324fd03ec23e373", null ]
];