var senial__01__imagen_8h =
[
    [ "senial_01_en_linea", "senial__01__imagen_8h.html#a89e4ac1fd1ce2c53b1e5bea5d93a60f9", null ]
];