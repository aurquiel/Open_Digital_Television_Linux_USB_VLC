var dir_bdd3766fb0ddcb5b16ef29dc6246f687 =
[
    [ "calls.h", "calls_8h.html", "calls_8h" ],
    [ "initialize.h", "initialize_8h.html", "initialize_8h" ],
    [ "samsung.h", "samsung_8h.html", "samsung_8h" ],
    [ "thread.h", "thread_8h.html", "thread_8h" ],
    [ "usb.h", "usb_8h.html", "usb_8h" ]
];