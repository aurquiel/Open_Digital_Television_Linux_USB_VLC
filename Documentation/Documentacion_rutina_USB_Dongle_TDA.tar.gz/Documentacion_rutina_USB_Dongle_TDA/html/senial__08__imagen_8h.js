var senial__08__imagen_8h =
[
    [ "senial_08_en_linea", "senial__08__imagen_8h.html#a4826b7be8f3ae4b9042fe345f5902a36", null ]
];