var pantalla__completa__imagen_8h =
[
    [ "pantalla_completa_en_linea", "pantalla__completa__imagen_8h.html#a7ee3afc4a98cf021b3b7b9c43555c095", null ]
];