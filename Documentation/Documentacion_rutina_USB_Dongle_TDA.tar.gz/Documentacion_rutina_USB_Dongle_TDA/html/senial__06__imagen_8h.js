var senial__06__imagen_8h =
[
    [ "senial_06_en_linea", "senial__06__imagen_8h.html#a35f67866c5643d560772a2537c5339b9", null ]
];