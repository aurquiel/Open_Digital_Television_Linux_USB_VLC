var senial__09__imagen_8h =
[
    [ "senial_09_en_linea", "senial__09__imagen_8h.html#aa51441a2f8d4302a1d137b1e31910534", null ]
];