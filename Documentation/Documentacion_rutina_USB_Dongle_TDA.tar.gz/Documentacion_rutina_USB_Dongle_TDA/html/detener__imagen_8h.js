var detener__imagen_8h =
[
    [ "detener_en_linea", "detener__imagen_8h.html#a72d2a8a27e0522a2e3a65b5a3f074a3a", null ]
];