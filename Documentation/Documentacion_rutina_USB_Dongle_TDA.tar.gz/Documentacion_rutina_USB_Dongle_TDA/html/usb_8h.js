var usb_8h =
[
    [ "funcion_de_llamada_hotplug", "usb_8h.html#aedf8f7d2aa43cba383f4b37cd6db18ad", null ],
    [ "funcion_leer_estado_frecuencia", "usb_8h.html#a5303f5d9ccd710290faae9ffa5158b48", null ],
    [ "funcion_leer_estado_hotplug", "usb_8h.html#a3cec16181dc77184c2fbfa0197f65389", null ],
    [ "procedimiento_escribir_estado_frecuencia", "usb_8h.html#aadf7718a66e8b795195fc752b7a8cc43", null ],
    [ "procedimiento_escribir_estado_hotplug", "usb_8h.html#a09f1a5f97e133e27ad9af2f89af07064", null ],
    [ "procedimiento_hotplug", "usb_8h.html#a2db52d59cf47386e322b03b3bb58a7ba", null ],
    [ "contexto_usb", "usb_8h.html#ad2bf984fc2cfbed0022fbbc3075cabb7", null ],
    [ "estado_frecuencia", "usb_8h.html#a02f7ac75eb45545d734b3600ab073d3a", null ],
    [ "estado_hotplug", "usb_8h.html#a50bc149fa79cc128049afb356ae3a298", null ],
    [ "manejador_dispositivo_usb", "usb_8h.html#acfd925acc79e3c59bb8544b50dc94388", null ]
];