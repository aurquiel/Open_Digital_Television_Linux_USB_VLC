var pausar__imagen_8h =
[
    [ "pausar_en_linea", "pausar__imagen_8h.html#a9c693cb059f698d7b1f7b52002b56875", null ]
];