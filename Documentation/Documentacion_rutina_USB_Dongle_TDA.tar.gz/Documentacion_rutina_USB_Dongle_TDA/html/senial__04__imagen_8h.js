var senial__04__imagen_8h =
[
    [ "senial_04_en_linea", "senial__04__imagen_8h.html#ad94108e5eaec2590dfb4c35ae14eb86a", null ]
];