var searchData=
[
  ['leer_5fmedia',['leer_media',['../calls_8h.html#a336835099eada3dc7065844939318a16',1,'calls.h']]],
  ['lptc90527data',['lpTC90527Data',['../samsung_8h.html#af0ccf745b082a5346a404748d35780fb',1,'samsung.h']]]
];
