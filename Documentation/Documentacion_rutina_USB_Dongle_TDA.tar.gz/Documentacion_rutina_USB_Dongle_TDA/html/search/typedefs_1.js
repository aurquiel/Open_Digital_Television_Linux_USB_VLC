var searchData=
[
  ['tc90527data',['TC90527Data',['../samsung_8h.html#a34320adab9c592e5ece29d79b76b80bb',1,'samsung.h']]]
];
