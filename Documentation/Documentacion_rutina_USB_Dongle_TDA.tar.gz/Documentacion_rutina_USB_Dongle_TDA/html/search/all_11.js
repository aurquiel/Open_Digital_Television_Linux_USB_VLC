var searchData=
[
  ['venevision_5fen_5flinea',['venevision_en_linea',['../venevision__imagen_8h.html#aa73886a1b7122f71744963f2eb58a96d',1,'venevision_imagen.h']]],
  ['venevision_5fimagen_2eh',['venevision_imagen.h',['../venevision__imagen_8h.html',1,'']]],
  ['ventana',['ventana',['../calls_8h.html#aefd737db03b2e0a789598136c640a009',1,'calls.h']]],
  ['ventana_5fdesplazamiento',['ventana_desplazamiento',['../calls_8h.html#ab851596a73fd11f529d56c4f8db89e1a',1,'calls.h']]],
  ['vive_5fen_5flinea',['vive_en_linea',['../vive__imagen_8h.html#a615243364f430f38837886e677c95b2e',1,'vive_imagen.h']]],
  ['vive_5fimagen_2eh',['vive_imagen.h',['../vive__imagen_8h.html',1,'']]],
  ['volumen',['volumen',['../calls_8h.html#a060893625ee7325d80977d9621cec33e',1,'calls.h']]],
  ['vtv_5fen_5flinea',['vtv_en_linea',['../vtv__imagen_8h.html#a4118e07599cea0d256e45a67db3204a5',1,'vtv_imagen.h']]],
  ['vtv_5fimagen_2eh',['vtv_imagen.h',['../vtv__imagen_8h.html',1,'']]]
];
