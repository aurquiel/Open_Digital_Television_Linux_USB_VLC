var searchData=
[
  ['funcion_5fcombinar_5fbytes',['funcion_combinar_bytes',['../samsung_8h.html#a670dd552865784837e63c3be932a8bed',1,'samsung.h']]],
  ['funcion_5fcrear_5ftransferencia_5fusb',['funcion_crear_transferencia_usb',['../thread_8h.html#ada281d0fd691df68147597716e161664',1,'thread.h']]],
  ['funcion_5fde_5fllamada_5fhotplug',['funcion_de_llamada_hotplug',['../usb_8h.html#aedf8f7d2aa43cba383f4b37cd6db18ad',1,'usb.h']]],
  ['funcion_5fleer_5fcalidad_5fsenial',['funcion_leer_calidad_senial',['../thread_8h.html#a2f0453b0bb41a16dfd1d9303bc764e79',1,'thread.h']]],
  ['funcion_5fleer_5festado_5fdetener',['funcion_leer_estado_detener',['../thread_8h.html#ad463f960866f59ca3438e8f9eb2277bb',1,'thread.h']]],
  ['funcion_5fleer_5festado_5ffrecuencia',['funcion_leer_estado_frecuencia',['../usb_8h.html#a5303f5d9ccd710290faae9ffa5158b48',1,'usb.h']]],
  ['funcion_5fleer_5festado_5fhotplug',['funcion_leer_estado_hotplug',['../usb_8h.html#a3cec16181dc77184c2fbfa0197f65389',1,'usb.h']]],
  ['funcion_5fleer_5fid',['funcion_leer_id',['../initialize_8h.html#a45f8e6ce4636694db653484790a1f73d',1,'initialize.h']]]
];
