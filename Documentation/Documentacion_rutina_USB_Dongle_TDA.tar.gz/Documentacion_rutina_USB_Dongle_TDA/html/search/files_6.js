var searchData=
[
  ['pantalla_5fcompleta_5fimagen_2eh',['pantalla_completa_imagen.h',['../pantalla__completa__imagen_8h.html',1,'']]],
  ['pausar_5fimagen_2eh',['pausar_imagen.h',['../pausar__imagen_8h.html',1,'']]],
  ['pdvsatv_5fimagen_2eh',['pdvsatv_imagen.h',['../pdvsatv__imagen_8h.html',1,'']]]
];
