var searchData=
[
  ['usb_5fconectado_5fen_5flinea',['usb_conectado_en_linea',['../usb__conectado__imagen_8h.html#a1e65cf069c37c6e863a5e17fc70123fc',1,'usb_conectado_imagen.h']]],
  ['usb_5fdesconectado_5fen_5flinea',['usb_desconectado_en_linea',['../usb__desconectado__imagen_8h.html#aa7b4cebf72e8b244b3f0c22987986731',1,'usb_desconectado_imagen.h']]]
];
