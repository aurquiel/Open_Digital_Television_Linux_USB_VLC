var searchData=
[
  ['detener_5fimagen_2eh',['detener_imagen.h',['../detener__imagen_8h.html',1,'']]]
];
