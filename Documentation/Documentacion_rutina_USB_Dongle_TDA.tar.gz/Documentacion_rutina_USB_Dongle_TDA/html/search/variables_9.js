var searchData=
[
  ['pantalla_5fcompleta',['pantalla_completa',['../calls_8h.html#af6f81cc4ffab62e3103fcbf867167435',1,'calls.h']]],
  ['pantalla_5fcompleta_5fen_5flinea',['pantalla_completa_en_linea',['../pantalla__completa__imagen_8h.html#a7ee3afc4a98cf021b3b7b9c43555c095',1,'pantalla_completa_imagen.h']]],
  ['pausar_5fen_5flinea',['pausar_en_linea',['../pausar__imagen_8h.html#a9c693cb059f698d7b1f7b52002b56875',1,'pausar_imagen.h']]],
  ['pdvsatv_5fen_5flinea',['pdvsatv_en_linea',['../pdvsatv__imagen_8h.html#a1315af96879dbd84fc37378820cfe97f',1,'pdvsatv_imagen.h']]],
  ['posicion',['posicion',['../thread_8h.html#a8fa2bfdda709afdfb0f36e9edac13ffe',1,'thread.h']]],
  ['posicion_5fmedia_5fbuffer',['posicion_media_buffer',['../calls_8h.html#afe3f729c15641484f7b330733f0055d4',1,'calls.h']]],
  ['post_5fber',['post_BER',['../struct___t_c90527_data.html#a5897d618eed6bb2ca12964c6c1b70069',1,'_TC90527Data']]],
  ['pre_5fber',['pre_BER',['../struct___t_c90527_data.html#a20f051aa3b1952afcc2d40d705a345e6',1,'_TC90527Data']]]
];
