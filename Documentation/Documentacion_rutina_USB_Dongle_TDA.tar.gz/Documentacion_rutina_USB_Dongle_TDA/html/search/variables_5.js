var searchData=
[
  ['fanbtv_5fen_5flinea',['fanbtv_en_linea',['../fanbtv__imagen_8h.html#af6d06e7a45dc9d20df55e38a56737289',1,'fanbtv_imagen.h']]],
  ['frame_5festado_5fusb',['frame_estado_usb',['../calls_8h.html#a6817d80db86b71e51e4142b112555ae2',1,'calls.h']]],
  ['frame_5fsenial',['frame_senial',['../calls_8h.html#a36aa5dd67df87826d568a816f7ca21e8',1,'calls.h']]]
];
