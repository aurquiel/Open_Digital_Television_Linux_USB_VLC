var searchData=
[
  ['abrir_5fmedia',['abrir_media',['../calls_8h.html#a86887970ba1e555a29f72fe11cb9fe4b',1,'calls.h']]],
  ['ajuste',['ajuste',['../calls_8h.html#ad5f24f1fd232ba9f7152407c699d1f07',1,'calls.h']]],
  ['alba_5fen_5flinea',['alba_en_linea',['../alba__imagen_8h.html#a6860c57b44d4e20bb6c3413502b6a810',1,'alba_imagen.h']]],
  ['alba_5fimagen_2eh',['alba_imagen.h',['../alba__imagen_8h.html',1,'']]],
  ['antv_5fen_5flinea',['antv_en_linea',['../antv__imagen_8h.html#aaae67fa8aa8584deb460a6db830fc75f',1,'antv_imagen.h']]],
  ['antv_5fimagen_2eh',['antv_imagen.h',['../antv__imagen_8h.html',1,'']]],
  ['apuntador_5fal_5fbuffer_5frecepcion_5fbts',['apuntador_al_buffer_recepcion_BTS',['../thread_8h.html#a519b5c5eabaa12faf7f35a0405010ab6',1,'thread.h']]],
  ['apuntador_5fdatos_5fdemulador',['apuntador_datos_demulador',['../samsung_8h.html#a2301cc77d0ec6341a7510b4e01d7c611',1,'samsung.h']]],
  ['avilatv_5fen_5flinea',['avilatv_en_linea',['../avilatv__imagen_8h.html#abe968489a5398481428154077c2d5517',1,'avilatv_imagen.h']]],
  ['avilatv_5fimagen_2eh',['avilatv_imagen.h',['../avilatv__imagen_8h.html',1,'']]]
];
