var searchData=
[
  ['senial_5f00_5fen_5flinea',['senial_00_en_linea',['../senial__00__imagen_8h.html#a30c1e6f39c1e0792b7ec48936338c1e3',1,'senial_00_imagen.h']]],
  ['senial_5f01_5fen_5flinea',['senial_01_en_linea',['../senial__01__imagen_8h.html#a89e4ac1fd1ce2c53b1e5bea5d93a60f9',1,'senial_01_imagen.h']]],
  ['senial_5f02_5fen_5flinea',['senial_02_en_linea',['../senial__02__imagen_8h.html#a0b4efc1734a57f1bae9dcaf2a7d361a7',1,'senial_02_imagen.h']]],
  ['senial_5f03_5fen_5flinea',['senial_03_en_linea',['../senial__03__imagen_8h.html#aa09b36c7d7ac2e3864a6dea5ab402976',1,'senial_03_imagen.h']]],
  ['senial_5f04_5fen_5flinea',['senial_04_en_linea',['../senial__04__imagen_8h.html#ad94108e5eaec2590dfb4c35ae14eb86a',1,'senial_04_imagen.h']]],
  ['senial_5f05_5fen_5flinea',['senial_05_en_linea',['../senial__05__imagen_8h.html#a4469c71cff08307f2482d2eee27ddcd2',1,'senial_05_imagen.h']]],
  ['senial_5f06_5fen_5flinea',['senial_06_en_linea',['../senial__06__imagen_8h.html#a35f67866c5643d560772a2537c5339b9',1,'senial_06_imagen.h']]],
  ['senial_5f07_5fen_5flinea',['senial_07_en_linea',['../senial__07__imagen_8h.html#a577a7eb051e1839afb5d9a63adf03c08',1,'senial_07_imagen.h']]],
  ['senial_5f08_5fen_5flinea',['senial_08_en_linea',['../senial__08__imagen_8h.html#a4826b7be8f3ae4b9042fe345f5902a36',1,'senial_08_imagen.h']]],
  ['senial_5f09_5fen_5flinea',['senial_09_en_linea',['../senial__09__imagen_8h.html#aa51441a2f8d4302a1d137b1e31910534',1,'senial_09_imagen.h']]],
  ['senial_5f10_5fen_5flinea',['senial_10_en_linea',['../senial__10__imagen_8h.html#a2519d113feff5fc2c324fd03ec23e373',1,'senial_10_imagen.h']]],
  ['sibci_5fen_5flinea',['sibci_en_linea',['../sibci__imagen_8h.html#a5df5116d579a828bdbafdbbe23654c69',1,'sibci_imagen.h']]],
  ['snr',['SNR',['../struct___t_c90527_data.html#a21b6ee353feba75027a7d19d2bb38d58',1,'_TC90527Data']]],
  ['stv4100_5freg',['STV4100_Reg',['../samsung_8h.html#ab672208dc42852a2d47f77ae6242ea46',1,'samsung.h']]]
];
