var searchData=
[
  ['caja_5fhorizontal_5fbotones_5fde_5fcontrol',['caja_horizontal_botones_de_control',['../calls_8h.html#a58adc4d6f24f494aaef16008787b4bfd',1,'calls.h']]],
  ['caja_5fhorizontal_5findicadores',['caja_horizontal_indicadores',['../calls_8h.html#a240d8a67fd3e70fc8a5cb8e9e10e9ced',1,'calls.h']]],
  ['caja_5fvertical_5fbotones_5fprogramacion',['caja_vertical_botones_programacion',['../calls_8h.html#a5f969cbf343fe49b38f7d4f65d13d6cf',1,'calls.h']]],
  ['caja_5fvertical_5fmayor',['caja_vertical_mayor',['../calls_8h.html#ac157e758c37f93a61e019335ff1978b1',1,'calls.h']]],
  ['cctv_5fen_5flinea',['cctv_en_linea',['../cctv__imagen_8h.html#aa380244659a9b50ba8d5c47bfb5fcd63',1,'cctv_imagen.h']]],
  ['code_5frate',['code_rate',['../struct___t_c90527_data.html#af9e02b59a07b9621436a2b817f76552e',1,'_TC90527Data']]],
  ['colombeia_5fen_5flinea',['colombeia_en_linea',['../colombeia__imagen_8h.html#a6b6e1545bc955ce5641bea34fa85a0f7',1,'colombeia_imagen.h']]],
  ['conciencia_5fen_5flinea',['conciencia_en_linea',['../conciencia__imagen_8h.html#ac14696aef3d9a339e7baf079bc49cd44',1,'conciencia_imagen.h']]],
  ['contador_5fevitar_5fbasura',['contador_evitar_basura',['../thread_8h.html#ac35a640166d6101cd7ed5daea31e0c53',1,'thread.h']]],
  ['contexto_5fusb',['contexto_usb',['../usb_8h.html#ad2bf984fc2cfbed0022fbbc3075cabb7',1,'usb.h']]],
  ['controlador_5fpantalla_5fcompleta',['controlador_pantalla_completa',['../calls_8h.html#a887e26120f51d9e9bab381ff3a95a4d3',1,'calls.h']]]
];
