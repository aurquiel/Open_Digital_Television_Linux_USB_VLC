var searchData=
[
  ['lptc90527data',['lpTC90527Data',['../samsung_8h.html#af0ccf745b082a5346a404748d35780fb',1,'samsung.h']]]
];
