var searchData=
[
  ['datos_5fdemulador',['datos_demulador',['../samsung_8h.html#ab5d8ef8884ac84a4ad118571a94c2d62',1,'samsung.h']]],
  ['desplazamiento',['desplazamiento',['../calls_8h.html#a27a93c3fd30e8d6e24933c9c1fd433f9',1,'calls.h']]],
  ['detener_5fen_5flinea',['detener_en_linea',['../detener__imagen_8h.html#a72d2a8a27e0522a2e3a65b5a3f074a3a',1,'detener_imagen.h']]],
  ['detener_5fimagen_2eh',['detener_imagen.h',['../detener__imagen_8h.html',1,'']]]
];
