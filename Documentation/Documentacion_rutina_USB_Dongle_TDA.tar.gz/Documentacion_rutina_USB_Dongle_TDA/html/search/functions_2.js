var searchData=
[
  ['leer_5fmedia',['leer_media',['../calls_8h.html#a336835099eada3dc7065844939318a16',1,'calls.h']]]
];
