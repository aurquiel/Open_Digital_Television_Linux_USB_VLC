var searchData=
[
  ['tc90527_5fi2cread',['TC90527_I2cRead',['../samsung_8h.html#a9b7c9d14591a35be4054d1ff3fbc027f',1,'samsung.h']]],
  ['tc90527_5fi2cwrite',['TC90527_I2cWrite',['../samsung_8h.html#a5cadb06a8a241e8aa637e58b2e5c6afa',1,'samsung.h']]]
];
