var searchData=
[
  ['icon',['icon',['../calls_8h.html#aa21dcaa3cd0a790475103816dacf22bd',1,'calls.h']]],
  ['icon_5fen_5flinea',['icon_en_linea',['../icon__imagen_8h.html#a706535d87158f75c2767e2f704804329',1,'icon_imagen.h']]],
  ['icon_5fimagen_2eh',['icon_imagen.h',['../icon__imagen_8h.html',1,'']]],
  ['id',['id',['../initialize_8h.html#afd0d68c6d31ff249f3ae8662162663c3',1,'initialize.h']]],
  ['imagen',['imagen',['../calls_8h.html#a333ad3c5277d539205e39d24a9e0ea81',1,'calls.h']]],
  ['initialize_2eh',['initialize.h',['../initialize_8h.html',1,'']]],
  ['instancia_5fvlc',['instancia_vlc',['../calls_8h.html#a079a7eef997d0edd2c88aa9fad2f3124',1,'calls.h']]]
];
