var searchData=
[
  ['fanbtv_5fen_5flinea',['fanbtv_en_linea',['../fanbtv__imagen_8h.html#af6d06e7a45dc9d20df55e38a56737289',1,'fanbtv_imagen.h']]],
  ['fanbtv_5fimagen_2eh',['fanbtv_imagen.h',['../fanbtv__imagen_8h.html',1,'']]],
  ['frame_5festado_5fusb',['frame_estado_usb',['../calls_8h.html#a6817d80db86b71e51e4142b112555ae2',1,'calls.h']]],
  ['frame_5fsenial',['frame_senial',['../calls_8h.html#a36aa5dd67df87826d568a816f7ca21e8',1,'calls.h']]],
  ['funcion_5fcombinar_5fbytes',['funcion_combinar_bytes',['../samsung_8h.html#a670dd552865784837e63c3be932a8bed',1,'samsung.h']]],
  ['funcion_5fcrear_5ftransferencia_5fusb',['funcion_crear_transferencia_usb',['../thread_8h.html#ada281d0fd691df68147597716e161664',1,'thread.h']]],
  ['funcion_5fde_5fllamada_5fhotplug',['funcion_de_llamada_hotplug',['../usb_8h.html#aedf8f7d2aa43cba383f4b37cd6db18ad',1,'usb.h']]],
  ['funcion_5fleer_5fcalidad_5fsenial',['funcion_leer_calidad_senial',['../thread_8h.html#a2f0453b0bb41a16dfd1d9303bc764e79',1,'thread.h']]],
  ['funcion_5fleer_5festado_5fdetener',['funcion_leer_estado_detener',['../thread_8h.html#ad463f960866f59ca3438e8f9eb2277bb',1,'thread.h']]],
  ['funcion_5fleer_5festado_5ffrecuencia',['funcion_leer_estado_frecuencia',['../usb_8h.html#a5303f5d9ccd710290faae9ffa5158b48',1,'usb.h']]],
  ['funcion_5fleer_5festado_5fhotplug',['funcion_leer_estado_hotplug',['../usb_8h.html#a3cec16181dc77184c2fbfa0197f65389',1,'usb.h']]],
  ['funcion_5fleer_5fid',['funcion_leer_id',['../initialize_8h.html#a45f8e6ce4636694db653484790a1f73d',1,'initialize.h']]]
];
