var indexSectionsWithContent =
{
  0: "_abcdefhilmoprstuv",
  1: "_",
  2: "acdfimprstuv",
  3: "aflmpst",
  4: "abcdefhimprstuv",
  5: "lt",
  6: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "&apos;typedefs&apos;",
  6: "&apos;defines&apos;"
};

