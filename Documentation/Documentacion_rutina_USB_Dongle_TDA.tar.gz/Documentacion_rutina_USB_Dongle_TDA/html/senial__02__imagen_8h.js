var senial__02__imagen_8h =
[
    [ "senial_02_en_linea", "senial__02__imagen_8h.html#a0b4efc1734a57f1bae9dcaf2a7d361a7", null ]
];