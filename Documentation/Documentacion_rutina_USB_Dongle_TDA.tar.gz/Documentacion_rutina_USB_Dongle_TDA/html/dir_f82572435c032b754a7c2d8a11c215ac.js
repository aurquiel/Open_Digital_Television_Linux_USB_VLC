var dir_f82572435c032b754a7c2d8a11c215ac =
[
    [ "alba_imagen.h", "alba__imagen_8h.html", "alba__imagen_8h" ],
    [ "antv_imagen.h", "antv__imagen_8h.html", "antv__imagen_8h" ],
    [ "avilatv_imagen.h", "avilatv__imagen_8h.html", "avilatv__imagen_8h" ],
    [ "cctv_imagen.h", "cctv__imagen_8h.html", "cctv__imagen_8h" ],
    [ "colombeia_imagen.h", "colombeia__imagen_8h.html", "colombeia__imagen_8h" ],
    [ "conciencia_imagen.h", "conciencia__imagen_8h.html", "conciencia__imagen_8h" ],
    [ "fanbtv_imagen.h", "fanbtv__imagen_8h.html", "fanbtv__imagen_8h" ],
    [ "meridiano_imagen.h", "meridiano__imagen_8h.html", "meridiano__imagen_8h" ],
    [ "pdvsatv_imagen.h", "pdvsatv__imagen_8h.html", "pdvsatv__imagen_8h" ],
    [ "russiatoday_imagen.h", "russiatoday__imagen_8h.html", "russiatoday__imagen_8h" ],
    [ "sibci_imagen.h", "sibci__imagen_8h.html", "sibci__imagen_8h" ],
    [ "telesur_imagen.h", "telesur__imagen_8h.html", "telesur__imagen_8h" ],
    [ "televen_imagen.h", "televen__imagen_8h.html", "televen__imagen_8h" ],
    [ "tv123_imagen.h", "tv123__imagen_8h.html", "tv123__imagen_8h" ],
    [ "tves_imagen.h", "tves__imagen_8h.html", "tves__imagen_8h" ],
    [ "venevision_imagen.h", "venevision__imagen_8h.html", "venevision__imagen_8h" ],
    [ "vive_imagen.h", "vive__imagen_8h.html", "vive__imagen_8h" ],
    [ "vtv_imagen.h", "vtv__imagen_8h.html", "vtv__imagen_8h" ]
];