var alba__imagen_8h =
[
    [ "alba_en_linea", "alba__imagen_8h.html#a6860c57b44d4e20bb6c3413502b6a810", null ]
];