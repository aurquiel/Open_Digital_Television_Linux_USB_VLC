var senial__00__imagen_8h =
[
    [ "senial_00_en_linea", "senial__00__imagen_8h.html#a30c1e6f39c1e0792b7ec48936338c1e3", null ]
];