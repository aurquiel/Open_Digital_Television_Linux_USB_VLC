var thread_8h =
[
    [ "funcion_crear_transferencia_usb", "thread_8h.html#ada281d0fd691df68147597716e161664", null ],
    [ "funcion_leer_calidad_senial", "thread_8h.html#a2f0453b0bb41a16dfd1d9303bc764e79", null ],
    [ "funcion_leer_estado_detener", "thread_8h.html#ad463f960866f59ca3438e8f9eb2277bb", null ],
    [ "procedimiento_ciclo_recepcion_BTS", "thread_8h.html#ad91375d22de5697a4a1310ff4f714375", null ],
    [ "procedimiento_de_llamada_leer_transferencia_usb", "thread_8h.html#a0839dd9b0e3cb80f2535bdb92c176386", null ],
    [ "procedimiento_escribir_estado_detener", "thread_8h.html#a9924670d65e469fbbe75804dfa392f32", null ],
    [ "apuntador_al_buffer_recepcion_BTS", "thread_8h.html#a519b5c5eabaa12faf7f35a0405010ab6", null ],
    [ "buffer", "thread_8h.html#a4c19c438eb66d16bad6ad237c4b06f6e", null ],
    [ "contador_evitar_basura", "thread_8h.html#ac35a640166d6101cd7ed5daea31e0c53", null ],
    [ "estado_detener", "thread_8h.html#acac06f5d02e99222ec41eda84626aae1", null ],
    [ "mensasje_recepcion", "thread_8h.html#a68eadeed1b8048d6803ed0afb4000518", null ],
    [ "MPEG2_TS", "thread_8h.html#ad2d9680c105ddb4e238ae1e879392c05", null ],
    [ "posicion", "thread_8h.html#a8fa2bfdda709afdfb0f36e9edac13ffe", null ],
    [ "tamanio_buffer", "thread_8h.html#a0cce9175201b89d47ad92699e747a11b", null ],
    [ "tamanio_buffer_MPEG_TS", "thread_8h.html#a801b97ef855044f20edd61101f726a35", null ]
];