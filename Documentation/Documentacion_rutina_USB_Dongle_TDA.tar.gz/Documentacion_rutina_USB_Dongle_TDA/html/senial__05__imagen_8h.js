var senial__05__imagen_8h =
[
    [ "senial_05_en_linea", "senial__05__imagen_8h.html#a4469c71cff08307f2482d2eee27ddcd2", null ]
];